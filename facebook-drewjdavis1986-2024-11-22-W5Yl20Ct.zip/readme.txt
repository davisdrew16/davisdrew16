This document contains information on what data logs are, how to navigate your download files and how to understand the data provided.


Data logs

Data logs are information we collect and store that can be associated with a profile on a Meta product. This data can be unique but it can also be additional details about information already provided in profile and account downloads. For example, in a profile and account download file, ‘Advertisers using your activity or information’ may contain information about advertisers who upload a list of information that we can match to a profile. Data logs may also contain the date an advertiser took this action.

In this sense, you can think of data logs as the more granular details of the data Meta collects and stores in our backend systems. Sometimes profile and account information and data logs can even overlap. Together they can be used to gain a fuller understanding of what data Meta collects and stores that can be associated with you.


File navigation

The data in these files are presented in table format. Each table contains a unique set of information.  To view a table, you can navigate to it in two ways:
Option 1: Navigate to the tables folder and open the .html file for the table you want to view.
Option 2: Open the index.html file, click on the link to see the table of contents and then click on the link for the table you want to view.


Understanding the data

Each table has table and column descriptions. The table description explains the set of data provided. Each column description explains the data in that column.

Sometimes you may see something other than data in a table:

Data unavailable
This data was available but we may not be able to share this data now. Some reasons for this include:
* Some content, like Stories, may have expired because it is only available for a short duration
* The audience for the content was changed and you are no longer able to view it
* The content was removed by either the person who shared it or Meta
* The profile that shared the content is no longer available on Facebook
* There is no data related to you for this field in this table